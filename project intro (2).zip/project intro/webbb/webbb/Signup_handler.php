<?php
@include 'config.php';
if(isset($_POST["submit"])){

   $name = $_POST['firstName'] ." ". $_POST['lastName'];
   $email = $_POST["email"];
   $phone =  $_POST["phone"];
   $password = $_POST["password"];

   $select = " SELECT * FROM user_form WHERE email = '$email' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

     echo ("<SCRIPT LANGUAGE='JavaScript'>
     window.alert('email is already used')
     window.location.href='Signup.php';
     </SCRIPT>");

   }else{

         $insert = "INSERT INTO user_form (name, email,phone,password)
          VALUES('$name','$email','$phone','$password')";
         mysqli_query($conn, $insert);
         header('location:Signin.php');

   }
};  
?>
