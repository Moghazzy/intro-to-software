<?php

@include 'config.php';

  session_start();
  
?>
<!DOCTYPE html>
<html>
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link rel="preconnect" href="https://fonts.gstatic.com">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
      <script src="https://kit.fontawesome.com/2565bea48f.js" crossorigin="anonymous"></script> 
      <link rel="stylesheet" href="CSSFile.css"> 
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

    </head>
    <body>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">ELite store</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="About us.php">About us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="Offers.php">Offers</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Clothes
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Male &raquo;</a>
                    <ul class="dropdown-menu submenu">
                        <li><a class="dropdown-item" href="Casual.php">Casual</a></li>
                        <li><a class="dropdown-item" href="Formal.php">Formal</a></li>
                        <li><a class="dropdown-item" href="Athome.php">At home</a></li>
                    </ul>
                  </li>
                  <li><a class="dropdown-item" href="#">Female &raquo;</a>
                    <ul class="dropdown-menu submenu">
                        <li><a class="dropdown-item" href="CasualG.php">Casual</a></li>
                        <li><a class="dropdown-item" href="FormalG.php">Formal</a></li>
                        <li><a class="dropdown-item" href="AthomeG.php">At home</a></li>
                    </ul>
                  </li>
                  <li><a class="dropdown-item" href="#">Children &raquo;</a>
                    <ul class="dropdown-menu submenu">
                        <li><a class="dropdown-item" href="CasualC.php">Casual</a></li>
                        <li><a class="dropdown-item" href="FormalC.php">Formal</a></li>
                        <li><a class="dropdown-item" href="AthomeC.php">At home</a></li>
                    </ul>
                  </li>
                </ul>
              </li>
            </ul>
        </div>
        <?php 
if(!isset($_SESSION['user_name'])){?>
    <form class="d-flex" role="search" action="Signin.php">
          <button class="btn btn-outline-success" type="submit">login</button>
        </form> 
 <?php }

else
{?>    <form class="d-flex" role="search" action="logout.php">
  <button class="btn btn-outline-success" type="submit">Log out</button>
</form> 
<?php } ?>
        <!--<div class="icons">
          <a href="#" class="fas fa-heart"></a>
          <a href="#" class="fas fa-shopping-cart"></a>
          <a href="#" class="fas fa-user"></a>
      </div>-->
      </div>
      </nav>
    <div class="container1">
     <div class="mycard">
      <div class="card" style="width: 18rem;">
        <img src="images/vest.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Vest</h5>
          <p class="card-text">Baby Boy Vest For Formal occasions and parties.</p>
          <p>425.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div> 
      <div class="card" style="width: 18rem;">
        <img src="images/dress2.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Dress</h5>
          <p class="card-text">est Gift Flower Girl Wedding Dress Kids Formal Long Pageant Princess Party Dresses For Girl Children Communion Gown Teenage Girl Clothes 4-14 Year.</p>
          <p>Price:500.0EGP</p>
          <a href="#" class="btn btn-primary">Buy</a>
        </div>
      </div>
      <div class="card" style="width: 18rem;">
        <img src="images/suit.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Suit</h5>
          <p class="card-text">5 Piece Baby Bodysuit (pants, shirt, pepon, vest and jacket).</p>
          <p>Price:475.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div>
      <div class="card" style="width: 18rem;">
        <img src="images/dress3.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Dress</h5>
          <p class="card-text">Little Girls' Ruffle Striped Belt Serpentine Dress, 3-4 Years.</p>
          <p>Price:229.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div> 
      <div class="card" style="width: 18rem;">
        <img src="images/vest.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Vest</h5>
          <p class="card-text">Baby Boy Vest For Formal occasions and parties.</p>
          <p>425.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div> 
      <div class="card" style="width: 18rem;">
        <img src="images/dress2.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Dress</h5>
          <p class="card-text">est Gift Flower Girl Wedding Dress Kids Formal Long Pageant Princess Party Dresses For Girl Children Communion Gown Teenage Girl Clothes 4-14 Year.</p>
          <p>Price:500.0EGP</p>
          <a href="#" class="btn btn-primary">Buy</a>
        </div>
      </div>
      <div class="card" style="width: 18rem;">
        <img src="images/suit.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Suit</h5>
          <p class="card-text">5 Piece Baby Bodysuit (pants, shirt, pepon, vest and jacket).</p>
          <p>Price:475.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div>
      <div class="card" style="width: 18rem;">
        <img src="images/dress3.jpg" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title">Dress</h5>
          <p class="card-text">Little Girls' Ruffle Striped Belt Serpentine Dress, 3-4 Years.</p>
          <p>Price:229.0EGP</p>
          <a href="#" class="btn btn-primary" style="margin-top: auto;">Buy</a>
        </div>
      </div> 
     </div>
    </div>
    
  
    <footer class="ct-footer">
        <div class="container">
          <form name="contentForm" enctype="multipart/form-data" method="post" action="">
            <div class="ct-footer-pre text-center-lg">
              <div class="inner">
                <span style="text-align: center;">We hope you enjoy your tour through the website.</span>
              </div>
            </div>
          </form>
          <ul class="ct-footer-list text-center-sm">
            <li>
              <h2 class="ct-footer-list-header">Clothes</h2>
              <ul>
                <li>
                  <p>Male</p>
                    <ul>
                      <li><a href="Casual.php">Casual</a></li>
                      <li><a href="Formal.php">Formal</a></li>
                      <li><a href="Athome.php">At home</a></li>
                    </ul>
                </li>
                <br>
                <li>
                  <p>Female</p>
                    <ul>
                      <li><a href="CasualG.php">Casual</a></li>
                      <li><a href="FormalG.php">Formal</a></li>
                      <li><a href="AthomeG.php">At home</a></li>
                    </ul>
                </li>
                <br>
                <li>
                  <p>Children</p>
                    <ul>
                      <li><a href="CasualC.php">Casual</a></li>
                      <li><a href="FormalC.php">Formal</a></li>
                      <li><a href="AthomeC.php">At home</a></li>
                    </ul>
                </li>
              </ul>
            </li>
            <li>
              <h2 class="ct-footer-list-header">Owners</h2>
              <ul>
                <li>
                  <p>Omar Mohamed</p>
                </li>
                <li>
                    <p>ahmed Amr</p>
                </li>
                <li>
                    <p>Mazen Samir</p>
                </li>
              </ul>
            </li>
            <li>
              <h2 class="ct-footer-list-header">Emails</h2>
              <ul>
                <li>
                  <p>omarmohammed182000@gmail.com</p>
                </li>
                <li>
                  <p>ahmed6amr@gmail.com</p>
                </li>
                <li>
                  <p>mazensamrir77@gmail.com</p>
                </li>
              </ul>
            </li>
            <li>
              <h2 class="ct-footer-list-header">Contact us</h2>
              <ul>
                <li>
                  <p>01282662825</p>
                </li>
                <li>
                  <p>01200303397</p>
                </li>
                <li>
                  <p>035261365</p>
                </li>
              </ul>
            </li>
            <li>
              <h2 class="ct-footer-list-header">Brands</h2>
              <ul>
                <li>
                  <a href="https://www.hollisterco.com/shop/wd">HOLLISTER</a>
                </li>
                <li>
                  <a href="https://www.americaneagle.com.eg/en/">American Egale</a>
                </li>
                <li>
                  <a href="https://www.zara.com/eg/">Zara</a>
                </li>
                <li>
                  <a href="https://us.shein.com/">SHEIN</a>
                </li>
              </ul>
            </li>
          </ul>
          <div class="ct-footer-meta text-center-sm">
            <div class="row">
              <div class="col-sm-6 col-md-3">
                <ul class="ct-socials list-unstyled list-inline">
                  <li>
                    <a href="" target="_blank"><img alt="facebook" src="https://www.solodev.com/assets/footer/facebook-white.png"></a>
                  </li>
                  <li>
                    <a href="" target="_blank"><img alt="twitter" src="https://www.solodev.com/assets/footer/twitter-white.png"></a>
                  </li>
                  <li>
                    <a href="" target="_blank"><img alt="youtube" src="https://www.solodev.com/assets/footer/youtube-white.png"></a>
                  </li>
                  <li>
                    <a href="" target="_blank"><img alt="instagram" src="https://www.solodev.com/assets/footer/instagram-white.png"></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
        </body>
    </html>