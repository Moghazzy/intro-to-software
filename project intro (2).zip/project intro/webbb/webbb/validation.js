var email = document.forms['form']['email'];
var password = document.forms['form']['password'];
var firstName = document.forms['form']['firstName'];
var lastName = document.forms['form']['lastName'];
var phone = document.forms['form']['phone'];
var passwordConfirm = document.forms['form']['passwordConfirm'];

var email_error = document.getElementById('email_error');
var pass_error = document.getElementById('pass_error');
var rpass_error = document.getElementById('rpass_error');
var lname_error = document.getElementById('lname_error');
var fname_error = document.getElementById('fname_error');
var phone_error = document.getElementById('phone_error');

email.addEventListener('textInput', email_Verify);
password.addEventListener('textInput', pass_Verify);
firstName.addEventListener('textInput',fname_verify);
lastName.addEventListener('textInput',lname_verify);
phone.addEventListener('textInput',phone_verify);
passwordConfirm.addEventListener('textInput',rpass_verify)

var regex = /^\w+@[a-zA-Z_]+\.[a-zA-Z]{2,6}$/;

function validated(){
	var regex1=  /^\w+@[a-zA-Z_]+\.[a-zA-Z]{2,6}$/;
	if (email.value.match(regex1) && password.value.length >= 6) {
			email.style.border = "1px solid silver";
			email_error.style.display = "none";
			password.style.border = "1px solid silver";
		    pass_error.style.display = "none";
			return true;
	}
	else if (password.value.length < 6){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid red";
		pass_error.style.display = "block";
		password.focus();
		return false;
	}
	else {
		email.style.border = "1px solid red";
		email_error.style.display = "block";
		email.focus();
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		return false;
	}

}
function validated2(){
	var regex1=  /^\w+@[a-zA-Z_]+\.[a-zA-Z]{2,6}$/;
	var regex2 = /^[a-zA-Z]+$/
	var regex3 = /^[^a-zA-Z]+$/
	if (email.value.match(regex1) 
	&& password.value.length >= 8
	&& phone.value.length == 11
	&& firstName.value.match(regex2) 
	&& lastName.value.match(regex2)
	&& passwordConfirm.value == password.value  ) {
			email.style.border = "1px solid silver";
			email_error.style.display = "none";
			password.style.border = "1px solid silver";
		    pass_error.style.display = "none";
			phone.style.border = "1px solid silver";
		    phone_error.style.display = "none";
			firstName.style.border = "1px solid silver";
		    fname_error.style.display = "none";
			lastName.style.border = "1px solid silver";
		    lname_error.style.display = "none";
			passwordConfirm.style.border = "1px solid silver";
		    rpass_error.style.display = "none";
			return true;
	}
	else if (firstName.value.match(regex3)){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		firstName.style.border = "1px solid red";
		fname_error.style.display = "block";
		lastName.style.border = "1px solid silver";
		lname_error.style.display = "none";
		phone.style.border = "1px solid silver";
		phone_error.style.display = "none";
		passwordConfirm.style.border = "1px solid silver";
		rpass_error.style.display = "none";
		firstName.focus();
		return false;
	}
	else if (lastName.value.match(regex3)){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		firstName.style.border = "1px solid silver";
		fname_error.style.display = "none";
		lastName.style.border = "1px solid red";
		lname_error.style.display = "block";
		phone.style.border = "1px solid silver";
		phone_error.style.display = "none";
		passwordConfirm.style.border = "1px solid silver";
		rpass_error.style.display = "none";
		lastName.focus();
		return false;
	}
	else if (phone.value.length != 11){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		firstName.style.border = "1px solid silver";
		fname_error.style.display = "none";
		lastName.style.border = "1px solid silver";
		lname_error.style.display = "none";
		phone.style.border = "1px solid red";
		phone_error.style.display = "block";
		passwordConfirm.style.border = "1px solid silver";
		rpass_error.style.display = "none";
		phone.focus();
		return false;
	}
	else if (password.value.length < 8){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid red";
		pass_error.style.display = "block";
		password.focus();
		return false;
	}
	else if (passwordConfirm.value != password.value){
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		firstName.style.border = "1px solid silver";
		fname_error.style.display = "none";
		lastName.style.border = "1px solid silver";
		lname_error.style.display = "none";
		phone.style.border = "1px solid silver";
		phone_error.style.display = "none";
		passwordConfirm.style.border = "1px solid red";
		rpass_error.style.display = "block";
		passwordConfirm.focus();
		return false;
	}
	else {
		email.style.border = "1px solid red";
		email_error.style.display = "block";
		email.focus();
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		firstName.style.border = "1px solid silver";
		fname_error.style.display = "none";
		lastName.style.border = "1px solid silver";
		lname_error.style.display = "none";
		phone.style.border = "1px solid silver";
		phone_error.style.display = "none";
		passwordConfirm.style.border = "1px solid silver";
		rpass_error.style.display = "none";
		return false;
	}

}
function email_Verify(){

	var regex = /^\w+@[a-zA-Z_]+\.[a-zA-Z]{2,6}$/;

	if (email.value.length >= 8 && email.value.match(regex)) {
		email.style.border = "1px solid silver";
		email_error.style.display = "none";
		return true;
	}
}
function pass_Verify(){
	if (password.value.length >= 8) {
		password.style.border = "1px solid silver";
		pass_error.style.display = "none";
		return true;
	}
}
function phone_verify(){
	if (phone.value.length == 11) {
		phone.style.border = "1px solid silver";
		phone_error.style.display = "none";
		return true;
	}
}
function fname_verify(){
	var regex1 = /^[a-zA-Z]+$/
	if (firstName.value.match(regex1)) {
		firstName.style.border = "1px solid silver";
		fname_error.style.display = "none";
		return true;
	}
}
function lname_verify(){
	var regex1 = /^[a-zA-Z]+$/
	if (lastName.value.match(regex1)) {
		lastName.style.border = "1px solid silver";
		lname_error.style.display = "none";
		return true;
	}
}
function rpass_verify(){
	if (passwordConfirm.value == password.value) {
		passwordConfirm.style.border = "1px solid silver";
		rpass_error.style.display = "none";
		return true;
	}
}

