<?php

@include 'config.php';

$email = $_POST ["email"];
$password = $_POST ["password"];

$select = " SELECT * FROM user_form WHERE email = '$email' and password = '$password' ";

$result = mysqli_query($conn, $select);

$count = mysqli_num_rows($result);

if(mysqli_num_rows($result) > 0){
    
    session_start();
    $row = mysqli_fetch_array($result);
    $_SESSION['user_name'] = $row['name'];
    header('location:index.php');
    }
    else{
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('wrong email or password press ok to back to Sign in Form')
        window.location.href='Signin.php';
        </SCRIPT>");
 }

?>